IR24W-A2-G3
-------------------------
This project utilizes libraries such as BeautifulSoup for parsing HTML content and NLTK for text processing tasks like tokenization and stopwords removal.

Team members
-------------------------
* Phuong Luong @pluong3
    - NetID: pluong3 
    - Student ID:62887840
    
* Yinxuan Liu @yinxual1
    - NetID: yinxual1
    - Student ID:70861360 
 
* Robin Stoebe @cstoebe
    - NetID: cstoebe
    - Student ID:63085315
    
* Navid Sharmsar @nsharmsa
    - NetID: nsharmsa
    - Student ID:66353809
