import re
import sys

def tokenize(TextFilePath):
    #Reads a text file and returns a list of tokens, but reads the file line by line to be more memory efficient
    #Runtime Complexity: O(n) where n = the number of chars in the file

    tokens = []
    with open (TextFilePath, 'r') as file:
        for line in file:
            text_line = line.lower()
            line_tokens = re.findall(r'\b\w+\b', text_line)
            tokens.extend(line_tokens)
    return tokens

def compute_word_frequencies(tokens):
    # Counts the frequency of each token in a given list of tokens by iterating through each token once, using a dictionary for counting.
    # Runtime Complexity O(n), where n = number of tokens.
    frequencies = {}
    for token in tokens:
        frequencies[token] = frequencies.get(token, 0) + 1

    return frequencies

def print_frequencies(frequencies):
    #Prints the frequencies of tokens. Tokens are sorted by a descending frequency and then alphabetically
    #Runtime Complexity: O(n log n) where n is the number of unique tokens
    for token in sorted(frequencies, key = lambda x:(-frequencies[x], x)):
        print(f"{token}\t{frequencies[token]}")

#main 
if __name__ == "__main__":
    if len(sys.argv) !=2:
        print("Usage: python PartA.py <TextFilePath")
        sys.exit(1)
    
    file_path = sys.argv[1]
    try:
        tokens = tokenize(file_path)
        frequencies = compute_word_frequencies(tokens)
        print_frequencies(frequencies)
    except Exception as e:
        print(f"Error occured: {e}")