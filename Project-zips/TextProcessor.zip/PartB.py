import PartA
import sys


def intersection(file_path1, file_path2):
    #Finds the intersection of tokens from two text files, tokenizes each file and finds the common tokens between them
    #Runtime complexity: O(n + m) where n and m are the number of characters in each file
    token_file1 = set(PartA.tokenize(file_path1))
    token_file2 = set(PartA.tokenize(file_path2))
    both_tokens = token_file1.intersection(token_file2)
    return both_tokens

if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("Usage: PartB.py <text_file1> <text_file2>")
        sys.exit(1)

    file_path1 = sys.argv[1]
    file_path2 = sys.argv[2]

    try:
        common_tokens = intersection(file_path1, file_path2)
        print(f"Number of common tokens: {len(common_tokens)}")
    except Exception as e:
        print(f"Error occurred: {e}")